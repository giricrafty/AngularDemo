package com.parser;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ConversionHandler {
	public String readJson(String selectedComponent, String[] selectedEvents, String[] selectedValidation) {
		
		JSONParser parser = new JSONParser();
		
		String htmlsnippet = "";
		try {
//			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
//			InputStream is = classloader.getResourceAsStream("test.csv");
			JSONObject data = (JSONObject) parser.parse(new FileReader("res/inputbs.json"));
			
			JSONObject sc = ((JSONObject)data.get(selectedComponent));
			
			if (sc != null)
			{
				htmlsnippet = sc.get("html").toString();
			    String bootstraphtmlsnippet = sc.get("bootstraphtml").toString();
			    
				
				
				
	//Events
				String events = "";
			    
			      for (int i = 0; i < selectedEvents.length; i++) {
			        events = events + " " + ((JSONObject)((JSONObject)data.get(selectedComponent)).get("event")).get(selectedEvents[i]).toString();
			      }
			      
			      
			      htmlsnippet = htmlsnippet.replace("<" + ((JSONObject)data.get(selectedComponent)).get("tag").toString(), "<" + ((JSONObject)data.get(selectedComponent)).get("tag").toString() + events);
			      
			      bootstraphtmlsnippet = bootstraphtmlsnippet.replace("<" + ((JSONObject)data.get(selectedComponent)).get("tag").toString(), "<" + ((JSONObject)data.get(selectedComponent)).get("tag").toString() + events);
			    		  
	//Validations 
			      String validations = "";
			      for (int i = 0; i < selectedValidation.length; i++) {
			        validations = validations + " " + ((JSONObject)((JSONObject)data.get(selectedComponent)).get("validation")).get(selectedValidation[i]).toString();
			      }
	
			      htmlsnippet = htmlsnippet.replace("<" + ((JSONObject)data.get(selectedComponent)).get("tag").toString(), "<" + ((JSONObject)data.get(selectedComponent)).get("tag").toString() + validations);
			      //String htmlTemplate = htmlsnippet.split("\"").join("");
			      bootstraphtmlsnippet = bootstraphtmlsnippet.replace("<" + ((JSONObject)data.get(selectedComponent)).get("tag").toString(), "<" + ((JSONObject)data.get(selectedComponent)).get("tag").toString() + validations);
			      //String bootstrapHtmlTemplate = bootstraphtmlsnippet.split("\"").join("");
	
	
	//TS template and SPEC template
			      String tsTemplate = "";
			      String specTemplate = "";
			      for (int i = 0; i < selectedEvents.length; i++) {
			        tsTemplate = tsTemplate + " " + ((JSONObject)((JSONObject)data.get(selectedComponent)).get("ts")).get(selectedEvents[i]).toString();
			        specTemplate = specTemplate + "<br/><br/>////Spec functionality for " + selectedEvents[i] + "<br/><br/>" + ((JSONObject)((JSONObject)data.get(selectedComponent)).get("unittest")).get(selectedEvents[i]).toString();
			      }
	
	//		      tsTemplate = tsTemplate.split("\"").join("<br/>");
	//		      this.tssnippet = tsTemplate;
	//		      specTemplate = specTemplate.split(';').join("<br/>");
	//		      specTemplate = specTemplate.split("\"").join("");
	//		      this.specsnippet = specTemplate;
	//		      htmlTemplate = htmlTemplate.split('>').join(">\n");
	//		      this.htmlsnippet = htmlTemplate;
	//		      this.bootstraphtmlsnippet = bootstrapHtmlTemplate;
			      
			    
	//		    String cssTmpt = ((JSONObject)data.get(selectedComponent)).get("css").toString();
	//		    String csssnippet = cssTmpt;
	////		    String csssnippet = cssTmpt.split("\"").join("");
	//		    
	//		    
	//		    String bscssTmp = ((JSONObject)data.get(selectedComponent)).get("bootstrapcss").toString();
	//		    String bscsssnippet = bscssTmp;
	//		    
	//		    String tscodesnippet = ((JSONObject)data.get(selectedComponent)).get("tscode").toString();
	//		    		    
	//		    String importTmpt = ((JSONObject)data.get(selectedComponent)).get("import").toString();
	//		    String importsnippet = importTmpt;
	//		    this.importsnippet = importTmpt.split(";").join(";\n");
			    
				
			}
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(htmlsnippet.isEmpty())
			return selectedComponent;
		else
			return htmlsnippet;
	}
}

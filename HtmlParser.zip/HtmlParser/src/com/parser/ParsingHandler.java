package com.parser;
import java.io.IOException;
import java.util.Stack;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ParsingHandler {

	static Stack<String> stk = new Stack<String>();
	
	public static void main(String[] args) {
//		String html = "<html><head><title>Sample Title</title></head>" + "<body><p>Sample Content</p></body></html>";
//		Document document = Jsoup.parse(html);
//		System.out.println(document.title());
//		Elements paragraphs = document.getElementsByTag("p");
//		for (Element paragraph : paragraphs) {
//			System.out.println(paragraph.text());
//		}
		ConversionHandler ch = new ConversionHandler();
//		String[] event={"keyup","keyupenter"};
//		String[] validation = {"required"};
		String[] event={};
		String[] validation = {};
		
		try {
			
			String url = "http://www.google.com";
			Document document = Jsoup.connect(url).get();
			
			Elements elements = document.body().children();
			//Elements elements = document.body().select("*");
			//Elements elements = document.body().children().select("*");

			for (Element element : elements) {
				System.out.println(ch.readJson(element.nodeName(), event , validation ));
				//System.out.println(element.nodeName());
				if(element.childrenSize()>0)
				{	
					ParsingHandler ph = new ParsingHandler();
					ParsingHandler.stk.push(element.nodeName());
					ph.getChildElements(element);
				}
			}
			//System.out.println(document.title());  
			
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void getChildElements(Element element)
	{
		ConversionHandler ch = new ConversionHandler();
		String[] event={};
		String[] validation = {};
		
		Elements childelements = element.children();
		for (Element childelement : childelements) {
			System.out.println(ch.readJson(childelement.nodeName(), event , validation ));
			//System.out.println(childelement.nodeName());
			ParsingHandler ph = new ParsingHandler();
			if(childelement.childrenSize()>0)
			{
				ParsingHandler.stk.push(childelement.nodeName());
				ph.getChildElements(childelement);
			}			
		}
		String tagname = ParsingHandler.stk.pop();
		System.out.println("tagname" + tagname);
	}
}